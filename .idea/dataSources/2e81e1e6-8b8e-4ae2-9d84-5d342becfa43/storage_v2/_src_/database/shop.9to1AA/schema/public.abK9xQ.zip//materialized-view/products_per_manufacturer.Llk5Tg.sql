create materialized view products_per_manufacturer as
SELECT p.manufacturer_id,
       count(p.id) AS num_products
FROM product p
         JOIN manufacturer m ON m.id = p.manufacturer_id
GROUP BY p.manufacturer_id;

alter materialized view products_per_manufacturer owner to postgres;

