create view products_per_category(category_id, num_products) as
SELECT p.category_id,
       count(p.id) AS num_products
FROM product p
         JOIN category c ON c.id = p.category_id
GROUP BY p.category_id;

alter table products_per_category
    owner to postgres;

